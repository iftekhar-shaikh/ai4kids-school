AI4Kids Class 2 Offline Pack
1) Zip extract karo
2) index.html Chrome/Edge mein kholo
3) Topic → Sabaq + Sunlo → KHELO → Quiz
Login nahi chahiye. WhatsApp: 0337 1468899
