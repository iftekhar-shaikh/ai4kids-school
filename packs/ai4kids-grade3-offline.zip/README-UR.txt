AI4Kids Class 3 Offline Pack
1) Zip extract karo
2) index.html Chrome/Edge mein kholo
3) Subject → topic dabao → app
Login nahi chahiye. WhatsApp: 0337 1468899
